from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import random
import uuid
from datetime import datetime, timedelta
import os
import json

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev_secret_key_change_in_production')

# Mock database
users = {
    "1": {
        "id": "1",
        "name": "John Smith",
        "company": "SportsDrink Co.",
        "email": "john@example.com",
        "password": "password123",  # For demo purposes, storing in plain text
        "budget": 50000
    },
    "2": {
        "id": "2",
        "name": "Jane Doe",
        "company": "Car Manufacturer",
        "email": "jane@example.com",
        "password": "password123",  # For demo purposes, storing in plain text
        "budget": 75000
    }
}

# Mock team and player data
teams = {
    "NYR": {
        "id": "NYR",
        "name": "New York Rangers",
        "conference": "Eastern",
        "division": "Metropolitan"
    },
    "BOS": {
        "id": "BOS",
        "name": "Boston Bruins",
        "conference": "Eastern",
        "division": "Atlantic"
    },
    "TOR": {
        "id": "TOR",
        "name": "Toronto Maple Leafs",
        "conference": "Eastern",
        "division": "Atlantic"
    },
    "MTL": {
        "id": "MTL",
        "name": "Montreal Canadiens",
        "conference": "Eastern",
        "division": "Atlantic"
    },
    "EDM": {
        "id": "EDM",
        "name": "Edmonton Oilers",
        "conference": "Western",
        "division": "Pacific"
    },
    "CGY": {
        "id": "CGY",
        "name": "Calgary Flames",
        "conference": "Western",
        "division": "Pacific"
    }
}

players = {
    # Rangers
    "NYR-1": {"id": "NYR-1", "name": "Igor Shesterkin", "team": "NYR", "position": "G", "number": 31, "stats": {"gaa": 2.48, "sv_pct": 0.916, "shutouts": 3}},
    "NYR-2": {"id": "NYR-2", "name": "Artemi Panarin", "team": "NYR", "position": "LW", "number": 10, "stats": {"goals": 32, "assists": 47, "points": 79}},
    "NYR-3": {"id": "NYR-3", "name": "Mika Zibanejad", "team": "NYR", "position": "C", "number": 93, "stats": {"goals": 28, "assists": 39, "points": 67}},
    "NYR-4": {"id": "NYR-4", "name": "Adam Fox", "team": "NYR", "position": "D", "number": 23, "stats": {"goals": 11, "assists": 54, "points": 65}},
    "NYR-5": {"id": "NYR-5", "name": "Chris Kreider", "team": "NYR", "position": "LW", "number": 20, "stats": {"goals": 36, "assists": 21, "points": 57}},

    # Bruins
    "BOS-1": {"id": "BOS-1", "name": "Jeremy Swayman", "team": "BOS", "position": "G", "number": 1, "stats": {"gaa": 2.32, "sv_pct": 0.921, "shutouts": 4}},
    "BOS-2": {"id": "BOS-2", "name": "David Pastrnak", "team": "BOS", "position": "RW", "number": 88, "stats": {"goals": 43, "assists": 38, "points": 81}},
    "BOS-3": {"id": "BOS-3", "name": "Brad Marchand", "team": "BOS", "position": "LW", "number": 63, "stats": {"goals": 26, "assists": 42, "points": 68}},
    "BOS-4": {"id": "BOS-4", "name": "Charlie McAvoy", "team": "BOS", "position": "D", "number": 73, "stats": {"goals": 8, "assists": 42, "points": 50}},
    "BOS-5": {"id": "BOS-5", "name": "Hampus Lindholm", "team": "BOS", "position": "D", "number": 27, "stats": {"goals": 9, "assists": 28, "points": 37}},

    # Maple Leafs
    "TOR-1": {"id": "TOR-1", "name": "Auston Matthews", "team": "TOR", "position": "C", "number": 34, "stats": {"goals": 51, "assists": 27, "points": 78}},
    "TOR-2": {"id": "TOR-2", "name": "Mitch Marner", "team": "TOR", "position": "RW", "number": 16, "stats": {"goals": 27, "assists": 53, "points": 80}},
    "TOR-3": {"id": "TOR-3", "name": "William Nylander", "team": "TOR", "position": "RW", "number": 88, "stats": {"goals": 33, "assists": 39, "points": 72}},
    "TOR-4": {"id": "TOR-4", "name": "John Tavares", "team": "TOR", "position": "C", "number": 91, "stats": {"goals": 29, "assists": 38, "points": 67}},
    "TOR-5": {"id": "TOR-5", "name": "Joseph Woll", "team": "TOR", "position": "G", "number": 60, "stats": {"gaa": 2.65, "sv_pct": 0.912, "shutouts": 1}},

    # Canadiens
    "MTL-1": {"id": "MTL-1", "name": "Cole Caufield", "team": "MTL", "position": "RW", "number": 22, "stats": {"goals": 26, "assists": 20, "points": 46}},
    "MTL-2": {"id": "MTL-2", "name": "Nick Suzuki", "team": "MTL", "position": "C", "number": 14, "stats": {"goals": 22, "assists": 34, "points": 56}},
    "MTL-3": {"id": "MTL-3", "name": "Mike Matheson", "team": "MTL", "position": "D", "number": 8, "stats": {"goals": 8, "assists": 31, "points": 39}},
    "MTL-4": {"id": "MTL-4", "name": "Sam Montembeault", "team": "MTL", "position": "G", "number": 35, "stats": {"gaa": 3.05, "sv_pct": 0.904, "shutouts": 1}},
    "MTL-5": {"id": "MTL-5", "name": "Kirby Dach", "team": "MTL", "position": "C", "number": 77, "stats": {"goals": 14, "assists": 24, "points": 38}},

    # Oilers
    "EDM-1": {"id": "EDM-1", "name": "Connor McDavid", "team": "EDM", "position": "C", "number": 97, "stats": {"goals": 42, "assists": 66, "points": 108}},
    "EDM-2": {"id": "EDM-2", "name": "Leon Draisaitl", "team": "EDM", "position": "C", "number": 29, "stats": {"goals": 38, "assists": 58, "points": 96}},
    "EDM-3": {"id": "EDM-3", "name": "Zach Hyman", "team": "EDM", "position": "LW", "number": 18, "stats": {"goals": 33, "assists": 31, "points": 64}},
    "EDM-4": {"id": "EDM-4", "name": "Evan Bouchard", "team": "EDM", "position": "D", "number": 2, "stats": {"goals": 12, "assists": 35, "points": 47}},
    "EDM-5": {"id": "EDM-5", "name": "Stuart Skinner", "team": "EDM", "position": "G", "number": 74, "stats": {"gaa": 2.68, "sv_pct": 0.908, "shutouts": 2}},

    # Flames
    "CGY-1": {"id": "CGY-1", "name": "Jacob Markstrom", "team": "CGY", "position": "G", "number": 25, "stats": {"gaa": 2.75, "sv_pct": 0.911, "shutouts": 2}},
    "CGY-2": {"id": "CGY-2", "name": "Nazem Kadri", "team": "CGY", "position": "C", "number": 91, "stats": {"goals": 24, "assists": 37, "points": 61}},
    "CGY-3": {"id": "CGY-3", "name": "Elias Lindholm", "team": "CGY", "position": "C", "number": 28, "stats": {"goals": 22, "assists": 28, "points": 50}},
    "CGY-4": {"id": "CGY-4", "name": "Rasmus Andersson", "team": "CGY", "position": "D", "number": 4, "stats": {"goals": 10, "assists": 36, "points": 46}},
    "CGY-5": {"id": "CGY-5", "name": "Blake Coleman", "team": "CGY", "position": "C", "number": 20, "stats": {"goals": 23, "assists": 19, "points": 42}}
}

strategies = {}

moments = {
    1: {
        "id": 1,
        "name": "Goal",
        "description": "Player scores a goal",
        "exposure": "High",
        "avg_bid": "$5,000",
        "frequency": "5-7 per game"
    },
    2: {
        "id": 2,
        "name": "Save",
        "description": "Goalkeeper makes a spectacular save",
        "exposure": "Medium",
        "avg_bid": "$2,500",
        "frequency": "10-15 per game"
    },
    3: {
        "id": 3,
        "name": "Penalty",
        "description": "Player receives a penalty",
        "exposure": "Medium",
        "avg_bid": "$3,000",
        "frequency": "8-12 per game"
    },
    4: {
        "id": 4,
        "name": "Fight",
        "description": "Players engage in a fight",
        "exposure": "Very High",
        "avg_bid": "$6,000",
        "frequency": "0-3 per game"
    },
    5: {
        "id": 5,
        "name": "Overtime Goal/Shootout",
        "description": "Game-winning goal in overtime or shootout",
        "exposure": "Extremely High",
        "avg_bid": "$8,000",
        "frequency": "0-1 per game"
    },
    6: {
        "id": 6,
        "name": "Hit",
        "description": "Player delivers a significant body check",
        "exposure": "Medium",
        "avg_bid": "$2,000",
        "frequency": "15-25 per game"
    }
}

upcoming_games = [
    {
        "id": 1,
        "home": "New York Rangers",
        "away": "Boston Bruins",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
        "time": "19:00 EST"
    },
    {
        "id": 2,
        "home": "Toronto Maple Leafs",
        "away": "Montreal Canadiens",
        "date": (datetime.now() + timedelta(days=2)).strftime("%Y-%m-%d"),
        "time": "20:00 EST"
    },
    {
        "id": 3,
        "home": "Edmonton Oilers",
        "away": "Calgary Flames",
        "date": (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d"),
        "time": "21:00 MST"
    }
]

sponsors = [
    {
        "id": 1,
        "name": "SportsDrink Co.",
        "budget": 50000,
        "strategy_count": 3
    },
    {
        "id": 2,
        "name": "Car Manufacturer",
        "budget": 75000,
        "strategy_count": 2
    },
    {
        "id": 3,
        "name": "Insurance Company",
        "budget": 100000,
        "strategy_count": 5
    }
]

# Budget calculation helper functions
def calculate_used_budget(user_id):
    """Calculate the total amount of budget used in all active strategies"""
    total_used = 0
    for strategy in strategies.values():
        if strategy['user_id'] == user_id:
            total_used += float(strategy.get('max_bid', 0))
    return total_used

def calculate_available_budget(user_id):
    """Calculate the available budget for a user"""
    user = users.get(user_id)
    if not user:
        return 0
    
    # Get the total budget from the user object
    total_budget = float(user.get('budget', 0))
    
    # Calculate used budget
    used_budget = calculate_used_budget(user_id)
    
    # Return the difference
    return max(0, total_budget - used_budget)

def debug_print_budget(user_id):
    """Print budget information for debugging"""
    user = users.get(user_id)
    if not user:
        print("User not found")
        return

    total_budget = float(user.get('budget', 0))
    
    print("\n=== BUDGET INFORMATION ===")
    print(f"User: {user.get('name')} (ID: {user_id})")
    print(f"Total Budget: ${total_budget:,.2f}")
    
    # Calculate used budget
    used_budget = 0
    print("\nActive strategies:")
    for strat_id, strategy in strategies.items():
        if strategy['user_id'] == user_id:
            max_bid = float(strategy.get('max_bid', 0))
            used_budget += max_bid
            moment_id = strategy.get('moment_id')
            moment_name = "Unknown"
            if moment_id in moments:
                moment_name = moments[moment_id]['name']
            print(f"  Strategy {strat_id}: {moment_name} - ${max_bid:,.2f}")
    
    print(f"\nTotal Used Budget: ${used_budget:,.2f}")
    print(f"Available Budget: ${max(0, total_budget - used_budget):,.2f}")
    print("=========================\n")

# Helper functions
def get_user():
    if 'user_id' in session:
        user_id = session['user_id']
        print(f"Getting user with ID: {user_id}")
        print(f"Available users: {list(users.keys())}")
        user = users.get(user_id)
        if user:
            # Add budget information for templates
            user['total_budget'] = float(user.get('budget', 0))
            user['used_budget'] = calculate_used_budget(user_id)
            user['available_budget'] = calculate_available_budget(user_id)
            return user
        else:
            print(f"User ID {user_id} not found in users dictionary")
    else:
        print("No user_id in session")
    return None

# Debug helper to print strategies in a readable format
def debug_print_strategies():
    print("\n=== CURRENT STRATEGIES ===")
    if not strategies:
        print("No strategies defined yet.")
    else:
        for strat_id, strategy in strategies.items():
            moment_name = moments.get(strategy.get('moment_id', 0), {}).get('name', 'Unknown Moment')
            user_name = users.get(strategy.get('user_id', ''), {}).get('name', 'Unknown User')
            game_id = strategy.get('game_id', 'Unknown Game')

            print(f"Strategy ID: {strat_id}")
            print(f"  User: {user_name} (ID: {strategy.get('user_id', '')})")
            print(f"  Moment: {moment_name} (ID: {strategy.get('moment_id', '')})")
            print(f"  Game ID: {game_id}")
            print(f"  Base Bid: ${strategy.get('base_bid', 0):.2f}")
            print(f"  Max Bid: ${strategy.get('max_bid', 0):.2f}")
            print("  ---------")
    print("========================\n")

# Routes
@app.route('/')
def index():
    return render_template('index.html', user=get_user())

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Debug message for tracking login attempts
    print("Login route accessed")

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Debug prints
        print(f"Login attempt: email={email}")
        print(f"Current users: {list(users.keys())}")

        # Simple validation
        if not email or not password:
            flash('Please fill out all fields.', 'error')
            return redirect(url_for('login'))

        # Check if user exists
        user_found = False
        for user_id, user in users.items():
            if user.get('email') == email:
                user_found = True
                # For demo purposes, directly compare passwords
                if password == user.get('password', ''):
                    session['user_id'] = user_id
                    flash('Login successful!', 'success')
                    print(f"Login successful for user_id={user_id}")
                    return redirect(url_for('dashboard'))
                else:
                    flash('Incorrect password.', 'error')
                    return redirect(url_for('login'))

        if not user_found:
            flash('User does not exist.', 'error')

        return redirect(url_for('login'))

    return render_template('login.html', user=get_user())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        company = request.form.get('company')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # Debug prints
        print(f"Received form data: name={name}, company={company}, email={email}")

        # Simple validation
        if not name or not company or not email or not password or not confirm_password:
            flash('Please fill out all fields.', 'error')
            return redirect(url_for('register'))

        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('register'))

        # Check if email already exists
        for user in users.values():
            if user.get('email') == email:
                flash('Email already exists.', 'error')
                return redirect(url_for('register'))

        # Create new user
        user_id = str(uuid.uuid4())
        users[user_id] = {
            'id': user_id,
            'name': name,
            'company': company,
            'email': email,
            'password': password,  # For demo, store plaintext
            'budget': 100000  # Default budget
        }

        # Debug print
        print(f"Created new user: {users[user_id]}")

        session['user_id'] = user_id
        flash('Registration successful!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('register.html', user=get_user())

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    # Debug print for budget
    print(f"\n=== DASHBOARD ACCESS ===")
    print(f"User: {user['name']} (ID: {user['id']})")
    print(f"Total Budget: ${user['total_budget']:,.2f}")
    print(f"Used Budget: ${user['used_budget']:,.2f}")
    print(f"Available Budget: ${user['available_budget']:,.2f}")

    # Get user's strategies to determine which moments have strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    # Debug prints
    print(f"Number of total strategies: {len(strategies)}")
    print(f"Number of user strategies: {len(user_strategies)}")

    if user_strategies:
        print("User strategies:")
        for strat_id, strategy in user_strategies.items():
            moment_name = moments.get(strategy.get('moment_id', 0), {}).get('name', 'Unknown')
            print(f"  {strat_id}: Game {strategy.get('game_id')}, Moment: {moment_name} (ID: {strategy.get('moment_id')})")
    else:
        print("User has no strategies")
    print(f"===========================\n")

    return render_template('dashboard.html', user=user, moments=moments,
                           upcoming_games=upcoming_games, user_strategies=user_strategies)

@app.route('/game/<int:game_id>')
def game_detail(game_id):
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    game = next((g for g in upcoming_games if g['id'] == game_id), None)
    if not game:
        flash('Game not found.', 'error')
        return redirect(url_for('dashboard'))

    # Get user's strategies for this specific game
    user_game_strategies = {}

    # Create a mapping of moment_id -> has_strategy for easy checking in the template
    moment_strategy_map = {}

    # Initialize the strategy map for all moments
    for moment_id in moments:
        moment_strategy_map[moment_id] = False

    # Process user strategies
    for strat_id, strategy in strategies.items():
        if strategy['user_id'] == user['id'] and strategy['game_id'] == game_id:
            # Create a copy of the strategy to avoid modifying the original
            strategy_copy = dict(strategy)

            # Store the strategy's moment ID as both string and integer
            moment_id = strategy_copy.get('moment_id')

            # Convert moment_id to proper types for consistent access
            if isinstance(moment_id, str):
                try:
                    strategy_copy['moment_id_int'] = int(moment_id)
                    strategy_copy['moment_id_str'] = moment_id
                except ValueError:
                    strategy_copy['moment_id_int'] = 0
                    strategy_copy['moment_id_str'] = moment_id
            else:
                strategy_copy['moment_id_int'] = moment_id
                strategy_copy['moment_id_str'] = str(moment_id)

            # Add the moment name for easier access in template
            int_moment_id = strategy_copy['moment_id_int']
            if int_moment_id in moments:
                strategy_copy['moment_name'] = moments[int_moment_id]['name']

                # Mark this moment as having a strategy
                moment_strategy_map[int_moment_id] = True
            else:
                strategy_copy['moment_name'] = "Unknown Moment"

            # Add to user game strategies
            user_game_strategies[strat_id] = strategy_copy

    # Add debug data to the template context
    debug_data = {
        'strategies_count': len(strategies),
        'user_game_strategies_count': len(user_game_strategies),
        'moment_strategy_map': moment_strategy_map
    }

    return render_template('game_detail.html',
                          user=user,
                          game=game,
                          moments=moments,
                          strategies=strategies,
                          user_strategies=user_game_strategies,
                          moment_strategy_map=moment_strategy_map,
                          debug_data=debug_data)

@app.route('/moment/<int:moment_id>')
def moment_detail(moment_id):
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    moment = moments.get(moment_id)
    if not moment:
        flash('Moment not found.', 'error')
        return redirect(url_for('dashboard'))

    # Get user's strategies to determine which moments already have strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    # Debug prints
    print(f"\n=== MOMENT DETAIL ACCESS ===")
    print(f"Moment ID: {moment_id} ({moment['name']})")
    print(f"User: {user['name']} (ID: {user['id']})")
    for strat_id, strategy in user_strategies.items():
        if strategy['moment_id'] == moment_id:
            game_id = strategy.get('game_id')
            print(f"  Found matching strategy: {strat_id} for game {game_id}")
    print(f"==============================\n")

    return render_template('moment_detail.html', user=user, moment=moment,
                           upcoming_games=upcoming_games, user_strategies=user_strategies)

@app.route('/setup_strategy/<int:moment_id>', methods=['GET', 'POST'])
def setup_strategy(moment_id):
    print("****** SETUP STRATEGY FUNCTION CALLED ******")
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    moment = moments.get(moment_id)
    if not moment:
        flash('Moment not found.', 'error')
        return redirect(url_for('dashboard'))

    # Get game_id from query string if present
    selected_game_id = request.args.get('game_id')
    if selected_game_id:
        selected_game_id = int(selected_game_id)

    # Get user's strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    # Debug prints
    print(f"\n=== SETUP STRATEGY ACCESS ===")
    print(f"Moment ID: {moment_id} ({moment['name']})")
    print(f"Selected Game ID: {selected_game_id}")
    print(f"User: {user['name']} (ID: {user['id']})")
    print(f"Method: {request.method}")

    if request.method == 'POST':
        # Get form data, with defaults for optional fields
        game_id = request.form.get('game_id')
        base_bid = request.form.get('base_bid')
        bid_increment = request.form.get('bid_increment', 500)  # New field with default
        max_bid = request.form.get('max_bid')
        team_focus = request.form.get('team_focus')
        player_focus = request.form.get('player_focus', '')
        period_restrictions = request.form.get('period_restrictions', '')

        # Debug prints for POST data
        print("POST DATA:")
        print(f"  game_id: {game_id}")
        print(f"  base_bid: {base_bid}")
        print(f"  max_bid: {max_bid}")
        print(f"  team_focus: {team_focus}")
        print(f"  player_focus: {player_focus}")

        # Get ad_content or use a default value for testing
        ad_content = request.form.get('ad_content', '')
        if not ad_content:
            ad_content = "https://example.com/test-ad.mp4"  # Default placeholder

        # Basic validation
        if not game_id or not base_bid or not max_bid or not team_focus:
            flash('Please fill in all required fields.', 'error')
            return render_template(
                'setup_strategy.html',
                user=user,
                moment=moment,
                upcoming_games=upcoming_games,
                teams=teams,
                players=players,
                selected_game_id=selected_game_id,
                user_strategies=user_strategies
            )

        # Convert values to appropriate types
        game_id = int(game_id)
        base_bid = float(base_bid)
        max_bid = float(max_bid)
        bid_increment = float(bid_increment)

        # Check if strategy already exists for this user, moment, and game
        existing_strategy_id = None
        old_max_bid = 0
        for strat_id, strat in strategies.items():
            if (strat['user_id'] == user['id'] and
                strat['moment_id'] == moment_id and
                strat['game_id'] == game_id):
                existing_strategy_id = strat_id
                old_max_bid = float(strat.get('max_bid', 0))
                print(f"  Found existing strategy ID: {existing_strategy_id}")
                break

        # Check if user has enough budget for this strategy
        available_budget = user['available_budget']
        if existing_strategy_id:
            # For existing strategy, we only need to check if the difference can be covered
            budget_needed = max_bid - old_max_bid
            if budget_needed > 0 and budget_needed > available_budget:
                flash(f'Insufficient budget. You need ${budget_needed:,.2f} more to increase your maximum bid.', 'error')
                return render_template(
                    'setup_strategy.html',
                    user=user,
                    moment=moment,
                    upcoming_games=upcoming_games,
                    teams=teams,
                    players=players,
                    selected_game_id=selected_game_id,
                    user_strategies=user_strategies,
                    existing_strategy=strategies.get(existing_strategy_id)
                )
        else:
            # For new strategy, check if the entire max_bid can be covered
            if max_bid > available_budget:
                flash(f'Insufficient budget. You need ${max_bid:,.2f} for this strategy but only have ${available_budget:,.2f} available.', 'error')
                return render_template(
                    'setup_strategy.html',
                    user=user,
                    moment=moment,
                    upcoming_games=upcoming_games,
                    teams=teams,
                    players=players,
                    selected_game_id=selected_game_id,
                    user_strategies=user_strategies
                )

        if existing_strategy_id:
            # Update existing strategy
            strategy_id = existing_strategy_id
            strategies[strategy_id].update({
                'base_bid': base_bid,
                'bid_increment': bid_increment,
                'max_bid': max_bid,
                'team_focus': team_focus,
                'player_focus': player_focus,
                'period_restrictions': period_restrictions,
                'ad_content': ad_content,
                'last_updated': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            print(f"  UPDATED existing strategy {strategy_id}")
            flash(f'{moment["name"]} Bidding Strategy Successfully Updated', 'success')
        else:
            # Create new strategy
            strategy_id = str(uuid.uuid4())
            strategies[strategy_id] = {
                'id': strategy_id,
                'user_id': user['id'],
                'moment_id': moment_id,
                'game_id': game_id,
                'base_bid': base_bid,
                'bid_increment': bid_increment,
                'max_bid': max_bid,
                'team_focus': team_focus,
                'player_focus': player_focus,
                'period_restrictions': period_restrictions,
                'ad_content': ad_content,
                'date_created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            print(f"  CREATED new strategy {strategy_id}")
            flash(f'{moment["name"]} Bidding Strategy Successfully Completed', 'success')

        # Debug print to show budget information after update
        debug_print_budget(user['id'])
        
        # Print all strategies after update
        debug_print_strategies()

        # Redirect to game details page for the game being bid on
        print(f"  Redirecting to game_detail with game_id={game_id}")
        print(f"=============================\n")
        return redirect(url_for('game_detail', game_id=game_id))

    # Check if strategy exists for this moment and game
    existing_strategy = None
    if selected_game_id:
        # Look for an existing strategy for this specific moment and game
        for strat_id, strat in user_strategies.items():
            if (strat['moment_id'] == moment_id and
                strat['game_id'] == selected_game_id):
                existing_strategy = strat
                print(f"  Found existing strategy for editing: {strat.get('id', 'Unknown ID')}")
                print(f"  Strategy details: base_bid={strat.get('base_bid')}, max_bid={strat.get('max_bid')}")
                break

    print(f"  Rendering setup_strategy template with existing_strategy: {existing_strategy is not None}")
    print(f"=============================\n")

    return render_template(
        'setup_strategy.html',
        user=user,
        moment=moment,
        upcoming_games=upcoming_games,
        teams=teams,
        players=players,
        selected_game_id=selected_game_id,
        user_strategies=user_strategies,
        existing_strategy=existing_strategy
    )

@app.route('/delete_strategy/<strategy_id>')
def delete_strategy(strategy_id):
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    # Check if strategy exists
    if strategy_id not in strategies:
        flash('Strategy not found.', 'error')
        return redirect(url_for('dashboard'))

    # Check if strategy belongs to the current user
    if strategies[strategy_id]['user_id'] != user['id']:
        flash('You do not have permission to delete this strategy.', 'error')
        return redirect(url_for('dashboard'))

    # Get the game_id before deleting the strategy
    game_id = strategies[strategy_id]['game_id']

    # Debug print before deletion
    max_bid = float(strategies[strategy_id].get('max_bid', 0))
    print(f"Deleting strategy {strategy_id} with max_bid ${max_bid:,.2f}")

    # Delete the strategy
    del strategies[strategy_id]

    # Debug print to show budget information after deletion
    debug_print_budget(user['id'])

    flash('Bidding strategy successfully removed.', 'success')

    # Allow override of redirect location
    redirect_game_id = request.args.get('redirect_game_id')
    if redirect_game_id:
        try:
            game_id = int(redirect_game_id)
        except ValueError:
            pass  # If conversion fails, use the original game_id

    # Redirect to the game detail page
    return redirect(url_for('game_detail', game_id=game_id))

@app.route('/my_strategies')
def my_strategies():
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    # Get only user's strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    # Add moment and game details to each strategy
    for strategy in user_strategies.values():
        strategy['moment'] = moments.get(strategy['moment_id'])
        strategy['game'] = next((g for g in upcoming_games if g['id'] == strategy['game_id']), None)

    # Debug prints
    print(f"\n=== MY STRATEGIES ACCESS ===")
    print(f"User: {user['name']} (ID: {user['id']})")
    print(f"Number of strategies: {len(user_strategies)}")
    for strat_id, strategy in user_strategies.items():
        moment_name = strategy.get('moment', {}).get('name', 'Unknown Moment')
        game_away = strategy.get('game', {}).get('away', 'Unknown')
        game_home = strategy.get('game', {}).get('home', 'Unknown')
        print(f"  Strategy {strat_id}: {moment_name} for {game_away} @ {game_home}")
    print(f"===========================\n")

    return render_template('my_strategies.html', user=user, strategies=user_strategies)

@app.route('/simulation')
def simulation():
    user = get_user()
    if not user:
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    # Get user's strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    return render_template('simulation.html', user=user, sponsors=sponsors, moments=moments, user_strategies=user_strategies)

@app.route('/api/simulate_auction', methods=['POST'])
def simulate_auction():
    data = request.json
    moment_id = data.get('moment_id')

    # Simulate an auction with the sponsors
    results = []
    for sponsor in sponsors:
        # Generate a random bid based on the sponsor's budget
        bid = round(random.uniform(1000, 10000), 2)
        results.append({
            'sponsor_id': sponsor['id'],
            'sponsor_name': sponsor['name'],
            'bid': bid
        })

    # Sort by bid (highest first)
    results.sort(key=lambda x: x['bid'], reverse=True)

    # Add a winning flag to the highest bidder
    if results:
        results[0]['winner'] = True

    return {'results': results}

@app.route('/api/toggle_strategy_status', methods=['POST'])
def toggle_strategy_status():
    data = request.json
    strategy_id = data.get('strategy_id')
    new_status = data.get('status')  # 'active' or 'inactive'

    if not strategy_id or strategy_id not in strategies:
        return {'success': False, 'message': 'Strategy not found'}, 404

    # Update strategy status
    strategies[strategy_id]['status'] = new_status

    return {'success': True, 'message': f'Strategy status updated to {new_status}'}

@app.route('/api/debug_info')
def debug_info():
    """API endpoint to dump debug information about the application state"""
    if 'user_id' not in session:
        return jsonify({
            'error': 'Not logged in',
            'message': 'Please login to view debug information'
        }), 401

    user = get_user()
    if not user:
        return jsonify({
            'error': 'User not found',
            'message': 'Could not find user data'
        }), 404

    # Get user's strategies
    user_strategies = {k: v for k, v in strategies.items() if v['user_id'] == user['id']}

    # Build debug information
    debug_info = {
        'user': {
            'id': user['id'],
            'name': user['name'],
            'email': user['email']
        },
        'strategies_count': len(strategies),
        'user_strategies_count': len(user_strategies),
        'strategies': {},
        'moments': {},
        'budget': {
            'total': user['total_budget'],
            'used': user['used_budget'],
            'available': user['available_budget']
        }
    }

    # Add strategy details
    for strat_id, strategy in user_strategies.items():
        debug_info['strategies'][strat_id] = {
            'moment_id': strategy.get('moment_id'),
            'game_id': strategy.get('game_id'),
            'base_bid': strategy.get('base_bid'),
            'max_bid': strategy.get('max_bid')
        }

    # Add moment mapping
    for moment_id, moment in moments.items():
        has_strategy = False
        strategy_ids = []
        for strat_id, strategy in user_strategies.items():
            if strategy.get('moment_id') == moment_id:
                has_strategy = True
                strategy_ids.append(strat_id)

        debug_info['moments'][moment_id] = {
            'name': moment.get('name'),
            'has_strategy': has_strategy,
            'strategy_ids': strategy_ids
        }

    return jsonify(debug_info)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html', user=get_user()), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html', user=get_user()), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
